v2.1.7

- Stability Fixes
- Fix Re-Index
- UI Transaction Sorting Update
- Multisend Fix
- Checkpoint added
- Update Translations
