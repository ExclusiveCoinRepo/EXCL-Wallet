EXCL Core integration/staging repository
=====================================

EXCL is an open source crypto-currency

More information at [exclusivecoin.pw](https://exclusivecoin.pw/)
Visit our ANN thread at [BitcoinTalk](https://bitcointalk.org/index.php?topic=1546005)

### Coin Specs
<table>
<tr><th>Algo</th><td>Quark</td></tr>
<tr><th>Block Time</th><td>60 Seconds</td></tr>
<tr><th>Difficulty Retargeting</th><td>Every Block</td></tr>
<tr><th>Min Stake Age</th><td>1 hour</td></tr>
<tr><th>Maturity</th><td>100 blocks</td></tr>
<tr><th>Port</th><td>23230</td></tr>
<tr><th>RPCPort</th><td>51473</td></tr>
</table>

<table>
<tr><th>Reward</th><th>Masternodes</th><th>Stakers</th></tr>
<tr><td>1 EXCL</td><td>50% (0.5 EXCL)</td><td>50% (0.5 EXCL)</td></tr>
</table>



  
