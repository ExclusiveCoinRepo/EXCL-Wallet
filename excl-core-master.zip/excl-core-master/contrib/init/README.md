Sample configuration files for:
```
SystemD: excld.service
Upstart: excld.conf
OpenRC:  excld.openrc
         excld.openrcconf
CentOS:  excld.init
macOS:    org.excl.excld.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
